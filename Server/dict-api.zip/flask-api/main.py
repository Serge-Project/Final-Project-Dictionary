from flask import Flask, request, jsonify
from flask_restful import Api, Resource, reqparse, abort, fields, marshal_with
from flask_cors import CORS, cross_origin
from scipy import interpolate
import numpy as np
import pandas as pd
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
api = Api(app)
class Dictionary (Resource):
	@cross_origin()
	def post(self):
		request_data = request.get_json()
		print (request_data)
		result = self.results()
		return result

	def results(self):
    	return {"test": "test"}
	
api.add_resource(Dictionary, "/dictionary")

if __name__ == "__main__":
	app.run(debug=True)